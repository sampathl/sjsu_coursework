#include <iostream>
#include <iterator>
#include "SortedVector.h"

using namespace std;

SortedVector::SortedVector()
{
    Node::reset();
}

SortedVector::~SortedVector()
{
    Node::reset();
}

int SortedVector::size() const { return datav.size(); }

bool SortedVector::check() const
{
    if (datav.size() == 0) return true;

    vector<Node>::const_iterator it = datav.begin();
    vector<Node>::const_iterator prev = it;

    it++;

    // Ensure that each node is greater than the previous node.
    while ((it != datav.end()) && (*it > *prev))
    {
        prev = it;
        it++;
    }

    return it == datav.end();  // Good if reached the end.
}

void SortedVector::prepend(const long value)
{
   Node prev_node(value);
   vector<Node>::iterator pos = datav.begin();
  datav.insert (pos, prev_node);
}

void SortedVector::append(const long value)
{
   Node app_node(value);
	datav.push_back(app_node);
}

void SortedVector::remove(const int index)
{
   vector<Node>::iterator pos = datav.begin();
   if(datav.size() > index)
	{
		datav.erase (pos+index);
	}
}

void SortedVector::insert(const long value)
{
   Node ins_node(value);
	vector<Node>::iterator pos;
	if(datav.size() != 0)
	{
		
		pos = datav.begin();

		while(*pos < ins_node)
		{
			if (pos == datav.end())
				break;
			pos++;
		}

		if(pos == datav.end())
		{
			datav.push_back(ins_node);
		}
		else
		{
			pos = datav.insert(pos,ins_node);
		}	
	}
	else
	{
		datav.push_back(ins_node);	
	}
}

Node SortedVector::at(const int index) const
{
   return datav[index];
}
