#include <iostream>
#include <iterator>
#include "SortedList.h"

using namespace std;

SortedList::SortedList()
{
    Node::reset();
}

SortedList::~SortedList()
{
    Node::reset();
}

int SortedList::size() const { return data.size(); }

bool SortedList::check()
{
    if (data.size() == 0) return true;

    list<Node>::iterator it = data.begin();
    list<Node>::iterator prev = it;

    it++;

    // Ensure that each node is greater than the previous node.
    while ((it != data.end()) && (*it > *prev))
    {
        prev = it;
        it++;
    }

    return it == data.end();  // Good if reached the end.
}

void SortedList::prepend(const long value)
{
      Node pre_node(value);
    data.push_front(pre_node);
}

void SortedList::append(const long value)
{
     Node app_node(value);
    data.push_back(app_node);
}

void SortedList::remove(const int index)
{
   int a;
   if(data.size() > index)
	{
	   list<Node>::iterator pos;
		pos = data.begin();
		
		for ( a=0; a < index;a++)
		{	pos++;}
		if( index==a )
		{
			pos = data.erase(pos);
		}  
	}
	
}

void SortedList::insert(const long value)
{
    Node ins_node(value);
    list<Node>::iterator pos;
	if(data.size() != 0)
	{
		
		pos = data.begin();
		while (*pos < ins_node)
		{
			if (pos == data.end())
				break;
			pos++;
		}
		if(pos == data.end())
		{
			data.push_back(ins_node);
		}
		else 
		{
			pos = data.insert(pos,ins_node);
		}
	}
	else
	{
		data.push_back(ins_node);
	}
}

Node SortedList::at(const int index)
{
   int a=0;
    if(data.size() > index)
	{
		list<Node>::iterator pos;
		pos = data.begin();
		
		for (a=0;a < index;a++)
		{
			pos++;
		}
		if (a==index) 
		{
			return *pos;
		}
		
	}
	else
	{
		return 0;
	}
	
}
